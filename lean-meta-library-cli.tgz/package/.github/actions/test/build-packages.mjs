#!/usr/bin/env node
// Runs `lake build` for both the root proof package and the nested surface package.
// This is the expensive check that confirms Lean accepts both packages.
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import {
  loadContext,
  maxBuildOutputBytes,
  packageRootForLakefile,
  proofLakefilePath,
  report,
  statementLakefilePath
} from "./common.mjs";

const { packageRoot, meta } = loadContext();
const errors = [];

if (spawnSync("lake", ["--version"], { encoding: "utf8" }).error) {
  errors.push("lake executable not found on PATH");
} else {
  for (const item of packageRoots()) {
    runLakeBuild(item.cwd, item.label);
  }
}

function packageRoots() {
  const items = [];
  const seen = new Set();
  addPackage("statement/declaration package", statementLakefilePath(meta));
  addPackage("proof package", proofLakefilePath(meta));
  return items;

  function addPackage(label, lakefilePath) {
    if (!lakefilePath) {
      return;
    }
    const cwd = packageRootForLakefile(packageRoot, lakefilePath);
    if (!cwd || seen.has(cwd)) {
      return;
    }
    seen.add(cwd);
    items.push({ label, cwd, lakefilePath });
  }
}

function runLakeBuild(cwd, label) {
  const result = spawnSync("lake", ["build"], {
    cwd,
    encoding: "utf8",
    maxBuffer: maxBuildOutputBytes
  });

  if (result.status !== 0) {
    errors.push(`${label} failed to build\n${result.stdout}${result.stderr}`.trim());
  }
}

report("build both packages", errors);
